<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "payments".
 *
 * @property int $payment_id
 * @property int $booking_id
 * @property int $amount
 * @property string $payment_date
 * @property string $status
 *
 * @property Booking $booking
 */
class Payments extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'payments';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['payment_id', 'booking_id', 'amount', 'payment_date', 'status'], 'required'],
            [['payment_id', 'booking_id', 'amount'], 'integer'],
            [['payment_date'], 'safe'],
            [['status'], 'string', 'max' => 50],
            [['booking_id'], 'exist', 'skipOnError' => true, 'targetClass' => Booking::className(), 'targetAttribute' => ['booking_id' => 'booking_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'payment_id' => 'Payment ID',
            'booking_id' => 'Booking ID',
            'amount' => 'Amount',
            'payment_date' => 'Payment Date',
            'status' => 'Status',
        ];
    }

    /**
     * Gets query for [[Booking]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBooking()
    {
        return $this->hasOne(Booking::className(), ['booking_id' => 'booking_id']);
    }
}
