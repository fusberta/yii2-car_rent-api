<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "cars".
 *
 * @property int $car_id
 * @property string|null $brand
 * @property string|null $model
 * @property int|null $year
 * @property string|null $reg_number
 * @property int|null $category_id
 * @property int $daily_price
 * @property string|null $status
 * @property string|null $image
 *
 * @property Booking[] $bookings
 * @property Categories $category
 * @property Reviews[] $reviews
 */
class Cars extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'cars';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['year', 'category_id', 'daily_price'], 'integer'],
            [['daily_price'], 'required'],
            [['brand', 'model'], 'string', 'max' => 100],
            [['reg_number'], 'string', 'max' => 25],
            [['status'], 'string', 'max' => 20],
            [['image'], 'string', 'max' => 255],
            [['category_id'], 'exist', 'skipOnError' => true, 'targetClass' => Categories::className(), 'targetAttribute' => ['category_id' => 'category_id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'car_id' => 'Car ID',
            'brand' => 'Brand',
            'model' => 'Model',
            'year' => 'Year',
            'reg_number' => 'Reg Number',
            'category_id' => 'Category ID',
            'daily_price' => 'Daily Price',
            'status' => 'Status',
            'image' => 'Image',
        ];
    }

    /**
     * Gets query for [[Bookings]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBookings()
    {
        return $this->hasMany(Booking::className(), ['car_id' => 'car_id']);
    }

    /**
     * Gets query for [[Category]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(Categories::className(), ['category_id' => 'category_id']);
    }

    /**
     * Gets query for [[Reviews]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getReviews()
    {
        return $this->hasMany(Reviews::className(), ['car_id' => 'car_id']);
    }
}
